    // 1、先创建package.json,npm init -y
    // 2、安装express和requests，npm i express requests
    // 3、通过requests请求爬取的网页，.on成功的数据
    let requests=require('requests')
    //4、文件读写操作，将爬取到的信息保存
    let fs=require('fs')
    let path=require('path')
    //5、安装cheerio（相当于Jquery），用来获取具体<div id="xx">中的数据
    //npm i --save cheerio
    const cheerio=require('cheerio')
    
    requests('https://ncov.dxy.cn/ncovh5/view/pneumonia_peopleapp?from=timeline&isappinstalled=0')
    .on('data', function (chunk) {
    console.log(chunk)

    //node没有window对象
    let window={}
     const $=cheerio.load(chunk)
    //eval可以让String语句当作js去执行
    //比如string "1+2" =6----->string "3"=6
    eval($("#getAreaStat").html())
    fs.writeFile(path.resolve(__dirname,'data.json'),
    JSON.stringify(window.getAreaStat),()=>{
            console.log("保存成功")
        //第一个参数是保存的路径：path.resolve(__dirname,'data.html')表示当前路径下的data.html
        //第二个参数是内容
        //第三个参数是成功的回调
    })
    })